
# DataMon EXPANDED

import AnswerChecker as aC # Shane's Program
import MemoryBank as mB # Damien's Program
import MissingNum as mN # Laila's Program
import numberGuesser as nG # Sejiro's Program

def menu():
    
    print("\nWelcome to DataMon!!!\n\n")
    print("Ready to test your mathematic capabilities?")
    
    print("Pick a game below: ")
    
    print("\n1) Answer Checker")
    print("2) Missing Num")
    print("3) Number Guesser")
    print("4) Memory Bank")
    print("5) Exit\n")
    
    choice = int(input("Choose a game here: "))
    return choice

def main():
    choice = menu()
    
    if choice == 1:
        aC.main()
    
    elif choice == 2:
        mB.main()
        
    elif choice == 3:
        mN.main()
        
    elif choice == 4:
        nG.main()
        
    elif choice == 5:
        print("ok bai")
        
    else:
        print("bro wtf are you talking about")
    
if __name__ == "__main__":
    main()