
# DataMon EXPANDED

import AnswerChecker as aC # Shane's Program
import MemoryBank as mB # Damien's Program
import MissingNum as mN # Laila's Program
import numberGuesser as nG # Sejiro's Program

def menu():
    
    print("\nWelcome to DataMon!!!\n\n")
    print("Ready to test your mathematic capabilities?")
    
    print("Pick a game below: ")
    
    print("\n1) Answer Checker")
    print("2) Memory Bank")
    print("3) Missing Num")
    print("4) Number Guesser")
    print("5) Exit\n")
    
    
    inValid = True   
    while inValid == True:
        
        try:
            choice = int(input("Choose a game here: "))
            inValid = False
            
        except ValueError:
            print("Invalid input. Please enter a number from 1-5\n")
        
    return choice

def main():
    
    running = "yes"
    
    while running == "yes":
        choice = menu()
        print()
        
        if choice == 1:
            aC.main()
        
        elif choice == 2:
            mB.main()
            
        elif choice == 3:
            mN.main()
            
        elif choice == 4:
            nG.main()
            
        elif choice == 5:
            break
            
        else:
            print("\nSorry, I didn't understand your input. Please try again.\n")
            
        running = input("\nWanna test your math skills once again? (Input yes/no): ").lower()
        
    print("\n\nProgram has ended. Thank you for playing datamon 💖💖💖\n\n")
    
if __name__ == "__main__":
    main()